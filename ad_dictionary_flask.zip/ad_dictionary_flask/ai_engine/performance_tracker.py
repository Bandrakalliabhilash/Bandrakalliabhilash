import sqlite3

def save_result(username, topic, difficulty, correct):
    conn = sqlite3.connect("database/learning.db")
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO user_performance (username, topic, difficulty, correct)
        VALUES (?, ?, ?, ?)
    """, (username, topic, difficulty, correct))

    conn.commit()
    conn.close()


def get_topic_accuracy(username):
    conn = sqlite3.connect("database/learning.db")
    cursor = conn.cursor()

    cursor.execute("""
        SELECT topic,
               SUM(correct) as total_correct,
               COUNT(*) as total_attempts
        FROM user_performance
        WHERE username = ?
        GROUP BY topic
    """, (username,))

    data = cursor.fetchall()
    conn.close()

    topic_accuracy = {}
    for topic, correct, attempts in data:
        accuracy = correct / attempts
        topic_accuracy[topic] = accuracy

    return topic_accuracy