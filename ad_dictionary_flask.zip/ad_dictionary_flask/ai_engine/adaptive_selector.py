from ai_engine.performance_tracker import get_topic_accuracy
import random

def choose_topic(username, available_topics):

    accuracy = get_topic_accuracy(username)

    if not accuracy:
        return random.choice(available_topics)

    # Find weakest topic
    weakest_topic = min(accuracy, key=accuracy.get)

    # 70% chance show weak topic
    if random.random() < 0.7:
        return weakest_topic
    else:
        return random.choice(available_topics)