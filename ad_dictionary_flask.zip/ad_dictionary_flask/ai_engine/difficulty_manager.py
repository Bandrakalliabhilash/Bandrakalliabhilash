def get_difficulty_level(username, topic_accuracy):

    if topic_accuracy >= 0.8:
        return "hard"
    elif topic_accuracy >= 0.5:
        return "medium"
    else:
        return "easy"